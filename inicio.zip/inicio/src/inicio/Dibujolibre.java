package inicio;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Ivan
 */
public class Dibujolibre extends javax.swing.JFrame {
    public Dibujolibre() {
        initComponents();
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Rectangulos = new javax.swing.JButton();
        PanelD = new javax.swing.JPanel();
        Ovalos = new javax.swing.JButton();
        Poligonos = new javax.swing.JButton();
        Arcos = new javax.swing.JButton();
        Limpiar = new javax.swing.JButton();
        Abecedario = new javax.swing.JButton();
        Cuadrados = new javax.swing.JButton();
        Circulos = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(450, 175));

        Rectangulos.setText("Rectangulos");
        Rectangulos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Rectangulos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RectangulosActionPerformed(evt);
            }
        });

        PanelD.setBackground(new java.awt.Color(24, 28, 28));
        PanelD.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Area de dibujo", javax.swing.border.TitledBorder.RIGHT, javax.swing.border.TitledBorder.BELOW_TOP, new java.awt.Font("Tahoma", 3, 14), new java.awt.Color(255, 153, 6))); // NOI18N
        PanelD.setForeground(new java.awt.Color(34, 34, 34));
        PanelD.setToolTipText("");
        PanelD.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        javax.swing.GroupLayout PanelDLayout = new javax.swing.GroupLayout(PanelD);
        PanelD.setLayout(PanelDLayout);
        PanelDLayout.setHorizontalGroup(
            PanelDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        PanelDLayout.setVerticalGroup(
            PanelDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 239, Short.MAX_VALUE)
        );

        Ovalos.setText("Ovalos");
        Ovalos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Ovalos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OvalosActionPerformed(evt);
            }
        });

        Poligonos.setText("Poligono");
        Poligonos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Poligonos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PoligonosActionPerformed(evt);
            }
        });

        Arcos.setText("Arcos");
        Arcos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Arcos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ArcosActionPerformed(evt);
            }
        });

        Limpiar.setText("Limpiar");
        Limpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LimpiarActionPerformed(evt);
            }
        });

        Abecedario.setText("Introduccion");
        Abecedario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Abecedario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AbecedarioActionPerformed(evt);
            }
        });

        Cuadrados.setText("Cuadrados");
        Cuadrados.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Cuadrados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CuadradosActionPerformed(evt);
            }
        });

        Circulos.setText("Circulos");
        Circulos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Circulos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CirculosActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Notas", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        jLabel2.setText("Orden de los botones");

        jLabel1.setText("1) Arcos");

        jLabel3.setText("2) Rectangulos");

        jLabel4.setText("3) Cuadrados ");

        jLabel5.setText("4) Poligono");

        jLabel6.setText("5) Circulos");

        jLabel7.setText("6) Ovalos");

        jLabel8.setText("7)Introduccion");

        jLabel9.setText("8)Limpiar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel8))))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(jLabel5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel6)
                    .addComponent(jLabel9)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Cuadrados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Rectangulos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Circulos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Ovalos, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Arcos, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                    .addComponent(Poligonos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Abecedario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Limpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(PanelD, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PanelD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(Rectangulos)
                                    .addComponent(Arcos)
                                    .addComponent(Abecedario)))
                            .addComponent(Ovalos))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Cuadrados)
                            .addComponent(Poligonos)
                            .addComponent(Circulos)
                            .addComponent(Limpiar)))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LimpiarActionPerformed
    PanelD.repaint();//limpia el panel
    }//GEN-LAST:event_LimpiarActionPerformed

    private void AbecedarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AbecedarioActionPerformed
    Graphics papel = PanelD.getGraphics();
    papel.setColor(Color.YELLOW);
    papel.drawString("Año 30XX la humanidad aprendio de sus errores, pero     ", 450,50);//dibuja la frase escrita
    papel.drawString("sus ambiciones de conocimiento los llevaron a despertar ", 450,70);
    papel.drawString("seres antiguos.                                         ", 450,90);
    papel.drawString("Estos seres estan llenos de odio y han comenzado a      ", 450,110);
    papel.drawString("destruir a la humanidad.                                ", 450,130);
    papel.drawString("Tu tienes la desicion de cambiar esto, puedes elegir    ", 450,150);
    papel.drawString("si salvar a todos o solo ver por ti.                    ", 450,170);
    papel.drawString("***********************************************************", 450,190);
    }//GEN-LAST:event_AbecedarioActionPerformed

    private void OvalosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OvalosActionPerformed
    Graphics papel = PanelD.getGraphics();
    papel.setColor(Color.LIGHT_GRAY);
    papel.fillOval(40, 45, 5, 20);//Dibuja los detalles de los ojos
    papel.fillOval(100, 105, 5, 20);
    papel.fillOval(175, 15, 5, 20);
    papel.fillOval(320, 70, 5, 20);
    papel.fillOval(230, 40, 5, 20);
    papel.fillOval(410, 45, 5, 20);
    }//GEN-LAST:event_OvalosActionPerformed

    private void PoligonosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PoligonosActionPerformed
    Graphics papel = PanelD.getGraphics();
    int x[]={310,340,380,390,380,370,360,340};
    int y[]={150,140,140,150,180,160,180,160};
    int x2[]={310,340,350,320};
    int y2[]={170,170,180,180};
    int x3[]={310,340,380,390,380,370,360,340};
    int y3[]={150,140,140,150,180,160,180,160};
    int x4[]={310,340,350,320};
    int y4[]={170,170,180,180};
    papel.setColor(Color.DARK_GRAY);
    papel.fillPolygon(x, y, 8);
    papel.fillPolygon(x2, y2, 4);
    papel.setColor(Color.MAGENTA);
    papel.drawPolygon(x3, y3, 8);
    papel.drawPolygon(x4, y4, 4);
    }//GEN-LAST:event_PoligonosActionPerformed

    private void ArcosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ArcosActionPerformed
    Graphics papel = PanelD.getGraphics();
    papel.setColor(Color.MAGENTA);
    papel.drawArc(39,39, 120, 120, 90, 300);
    papel.drawArc(200,120, 120, 120, 90, 300);
    papel.drawArc(360,0, 120, 120, 90, 210);
    }//GEN-LAST:event_ArcosActionPerformed

    private void CirculosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CirculosActionPerformed
    Graphics papel = PanelD.getGraphics();
    papel.setColor(Color.white);
    papel.fillOval(30,30, 40, 40);//Dibuja los ojos
    papel.fillOval(90,90, 40, 40);
    papel.fillOval(150,0, 40, 40);
    papel.fillOval(300,60, 40, 40);
    papel.fillOval(225,30, 40, 40);
    papel.fillOval(390,30, 40, 40);
    papel.setColor(Color.red);
    papel.drawOval(30,30, 40, 40);//Dibuja el contorno de los ojos
    papel.drawOval(90,90, 40, 40);
    papel.drawOval(150,0, 40, 40);
    papel.drawOval(300,60, 40, 40);
    papel.drawOval(225,30, 40, 40);
    papel.drawOval(390,30, 40, 40);
    }//GEN-LAST:event_CirculosActionPerformed

    private void CuadradosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CuadradosActionPerformed
    Graphics papel = PanelD.getGraphics();
    papel.setColor(Color.yellow);
    papel.fillRect(20,175,10,10);//ventanas edificios altos
    papel.fillRect(40,175,10,10);
    papel.fillRect(20,190,10,10);
    papel.fillRect(40,190,10,10);
    papel.fillRect(20,205,10,10);
    papel.fillRect(40,205,10,10);
    papel.fillRect(20,220,10,10);
    papel.fillRect(40,220,10,10);
    papel.fillRect(80,200,10,10);//ventanas edificios bajos
    papel.fillRect(100,200,10,10);
    papel.fillRect(80,215,10,10);
    papel.fillRect(100,215,10,10);
    papel.fillRect(80,230,10,10);
    papel.fillRect(100,230,10,10);
    papel.fillRect(160,175,10,10);//Ventanas altas
    papel.fillRect(140,175,10,10);
    papel.fillRect(160,190,10,10);
    papel.fillRect(140,190,10,10);
    papel.fillRect(160,205,10,10);
    papel.fillRect(140,205,10,10);
    papel.fillRect(160,220,10,10);
    papel.fillRect(140,220,10,10);
    papel.fillRect(200,200,10,10);//ventanas edificios bajos
    papel.fillRect(220,200,10,10);
    papel.fillRect(200,215,10,10);
    papel.fillRect(220,215,10,10);
    papel.fillRect(200,230,10,10);
    papel.fillRect(220,230,10,10);
    papel.fillRect(260,175,10,10);//Ventanas altas
    papel.fillRect(280,175,10,10);
    papel.fillRect(260,190,10,10);
    papel.fillRect(280,190,10,10);
    papel.fillRect(260,205,10,10);
    papel.fillRect(280,205,10,10);
    papel.fillRect(260,220,10,10);
    papel.fillRect(280,220,10,10);
    papel.fillRect(320,200,10,10);//ventanas edificios bajos
    papel.fillRect(340,200,10,10);
    papel.fillRect(320,215,10,10);
    papel.fillRect(340,215,10,10);
    papel.fillRect(320,230,10,10);
    papel.fillRect(340,230,10,10);
    papel.fillRect(400,175,10,10);//Ventanas altas
    papel.fillRect(380,175,10,10);
    papel.fillRect(400,190,10,10);
    papel.fillRect(380,190,10,10);
    papel.fillRect(400,205,10,10);
    papel.fillRect(380,205,10,10);
    papel.fillRect(400,220,10,10);
    papel.fillRect(380,220,10,10);
    papel.setColor(Color.cyan);
    papel.drawRect(20,175,10,10);//ventanas edificios altos
    papel.drawRect(40,175,10,10);
    papel.drawRect(20,190,10,10);
    papel.drawRect(40,190,10,10);
    papel.drawRect(20,205,10,10);
    papel.drawRect(40,205,10,10);
    papel.drawRect(20,220,10,10);
    papel.drawRect(40,220,10,10);
    papel.drawRect(80,200,10,10);//ventanas edificios bajos
    papel.drawRect(100,200,10,10);
    papel.drawRect(80,215,10,10);
    papel.drawRect(100,215,10,10);
    papel.drawRect(80,230,10,10);
    papel.drawRect(100,230,10,10);
    papel.drawRect(160,175,10,10);//Ventanas altas
    papel.drawRect(140,175,10,10);
    papel.drawRect(160,190,10,10);
    papel.drawRect(140,190,10,10);
    papel.drawRect(160,205,10,10);
    papel.drawRect(140,205,10,10);
    papel.drawRect(160,220,10,10);
    papel.drawRect(140,220,10,10);
    papel.drawRect(200,200,10,10);//ventanas edificios bajos
    papel.drawRect(220,200,10,10);
    papel.drawRect(200,215,10,10);
    papel.drawRect(220,215,10,10);
    papel.drawRect(200,230,10,10);
    papel.drawRect(220,230,10,10);
    papel.drawRect(260,175,10,10);//Ventanas altas
    papel.drawRect(280,175,10,10);
    papel.drawRect(260,190,10,10);
    papel.drawRect(280,190,10,10);
    papel.drawRect(260,205,10,10);
    papel.drawRect(280,205,10,10);
    papel.drawRect(260,220,10,10);
    papel.drawRect(280,220,10,10);
    papel.drawRect(320,200,10,10);//ventanas edificios bajos
    papel.drawRect(340,200,10,10);
    papel.drawRect(320,215,10,10);
    papel.drawRect(340,215,10,10);
    papel.drawRect(320,230,10,10);
    papel.drawRect(340,230,10,10);
    papel.drawRect(400,175,10,10);//Ventanas altas
    papel.drawRect(380,175,10,10);
    papel.drawRect(400,190,10,10);
    papel.drawRect(380,190,10,10);
    papel.drawRect(400,205,10,10);
    papel.drawRect(380,205,10,10);
    papel.drawRect(400,220,10,10);
    papel.drawRect(380,220,10,10);
    }//GEN-LAST:event_CuadradosActionPerformed

    private void RectangulosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RectangulosActionPerformed
    Graphics papel = PanelD.getGraphics();
    papel.setColor(Color.GRAY);//Edificios
    papel.fillRect( 10, 165, 50, 100);
    papel.fillRect( 70, 190, 50, 100);
    papel.fillRect( 130, 165, 50, 100);
    papel.fillRect( 190, 190, 50, 100);
    papel.fillRect( 250, 165, 50, 100);
    papel.fillRect( 310, 190, 50, 100);
    papel.fillRect( 370, 165, 50, 100);
    papel.setColor(Color.CYAN);//Puertas
    papel.fillRect( 30, 245, 10, 20);
    papel.fillRect( 90, 255, 10, 15);
    papel.fillRect( 150, 245, 10, 20);
    papel.fillRect( 210, 255, 10, 20);
    papel.fillRect( 270, 245, 10, 20);
    papel.fillRect( 330, 255, 10, 20);
    papel.fillRect( 390, 245, 10, 20);
    papel.setColor(Color.WHITE);//Borde de los dificios
    papel.drawRect( 10, 165, 50, 100);
    papel.drawRect( 70, 190, 50, 100);
    papel.drawRect( 130, 165, 50, 100);
    papel.drawRect( 190, 190, 50, 100);
    papel.drawRect( 250, 165, 50, 100);
    papel.drawRect( 310, 190, 50, 100);
    papel.drawRect( 370, 165, 50, 100);
    papel.setColor(Color.DARK_GRAY);//Bordes de las puertas
    papel.drawRect( 30, 245, 10, 20);
    papel.drawRect( 90, 255, 10, 15);
    papel.drawRect( 150, 245, 10, 20);
    papel.drawRect( 210, 255, 10, 20);
    papel.drawRect( 270, 245, 10, 20);
    papel.drawRect( 330, 255, 10, 20);
    papel.drawRect( 390, 245, 10, 20);
    }//GEN-LAST:event_RectangulosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Dibujolibre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Dibujolibre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Dibujolibre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dibujolibre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dibujolibre().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Abecedario;
    private javax.swing.JButton Arcos;
    private javax.swing.JButton Circulos;
    private javax.swing.JButton Cuadrados;
    private javax.swing.JButton Limpiar;
    private javax.swing.JButton Ovalos;
    private javax.swing.JPanel PanelD;
    private javax.swing.JButton Poligonos;
    private javax.swing.JButton Rectangulos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
