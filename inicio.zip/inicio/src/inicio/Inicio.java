package inicio;
public class Inicio {
    public static void main(String[] args) {
      Dibujolibre z=new Dibujolibre();
      z.setVisible(true);
    }
}
