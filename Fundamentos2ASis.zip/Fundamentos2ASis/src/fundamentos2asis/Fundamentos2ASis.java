/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fundamentos2asis;

/**
 *
 * @author A D A N
 */
public class Fundamentos2ASis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //instanciar la ventana principal
        Ventanita lolo = new Ventanita();
        lolo.setVisible(true);
        
    }
    
}
