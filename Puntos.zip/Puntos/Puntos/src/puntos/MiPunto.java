/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package puntos;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author A D A N
 */
public class MiPunto {
    
    int x;
    int y;
    
    /*
    Constructores de la clase
    */
    public MiPunto(){
        this.x = 0;
        this.y = 0;
    }
    
    public MiPunto(int x, int y){
        this.x = x;
        this.y = y;
    }
    
    /*
    Automatizacion getterts y setters
    clic derecho, insertar codigo
    seleccionar getter y setter y las vbles...
    */

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
    
////////////////////////////////////////////////////////////

 public void aumentar(Graphics areaDibujo, MiPunto punto){
        int x = punto.getX();// definir ubicacion del punto
        int y = punto.getY();

        //Tu código va aquí
        areaDibujo.drawLine(x, y, x + 1, y); //dibujar 1 pixel derecha
        areaDibujo.drawLine(x, y, x, y + 1); //dibujar 1 pixel abajo
        areaDibujo.drawLine(x, y, x - 1, y); //dibujar 1 pixel izquierda
        areaDibujo.drawLine(x, y, x, y - 1); //dibujar 1 pixel arriba
        
        
    }
     
     public void disminuir(Graphics areaDibujo, MiPunto punto){
        int x = punto.getX();
        int y = punto.getY();

        //tu código va aquí
        areaDibujo.setColor(Color.white);
        
        areaDibujo.drawLine(x + 1, y, x + 1, y); //dibujar 1 pixel derecha
        areaDibujo.drawLine(x, y + 1, x, y + 1); //dibujar 1 pixel abajo
        areaDibujo.drawLine(x - 1, y, x - 1, y); //dibujar 1 pixel izquierda
        areaDibujo.drawLine(x, y + 1, x, y - 1); //dibujar 1 pixel arriba
    }    
     
     //Metodos para la distancia
     
     public void dibujarDistancia(Graphics areaDibujo, 
             MiPunto punto1, MiPunto punto2){
        
       //aquí va tu codigo
       areaDibujo.drawLine(punto1.getX(), punto1.getY(),
                            punto2.getX(), punto2.getY());
       
    }
      
     public double calcularDistancia(MiPunto a, MiPunto b){
        double distancia = 0;
        
        int xDif = b.getX() - a.getX();
        int yDif = b.getY() - a.getY();
        
        //distancia = Math.sqrt(Math.pow(xDif, 2) + Math.pow(yDif, 2));
        
        distancia = Math.sqrt( (xDif * xDif) + (yDif * yDif));
        
        return distancia;
    }
     
     public void limpiarPanel (Graphics areaDibujo, JPanel panel){
         int ancho = panel.getWidth();
         int altura = panel.getHeight();
         
         areaDibujo.setColor(Color.white);
         areaDibujo.fillRect(0, 0, ancho, altura);
         
     }
     
     ///////////////////////////////////////////////////////////
     /*
     Dibujar en direcciones
     */
     public void avanzarDerecha(Graphics areaDibujo, int distancia){
         
         areaDibujo.drawLine(x, y, x + distancia, y);
     }
     
     public void avanzarArriba(Graphics areaDibujo, int distancia){
         
         areaDibujo.drawLine(x, y, x, y - distancia);
     }
     
     
    
}
