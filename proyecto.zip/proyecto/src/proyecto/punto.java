/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author Ivan
 */
public class punto {
    int x= 0;
    int y= 0;
    
public punto(){
    this.x = 0;
    this.y = 0;}
    
public punto(int x, int y){
    this.x = x;
    this.y = y;}

public int getX() {
    return x;}

public void setX(int x) {
    this.x = x;}

public int getY() {
    return y;}

public void setY(int y) {
    this.y = y;}
    
public void dibujarDistancia(Graphics areaDibujo, 
    punto punto1, punto punto2){
        
    areaDibujo.drawLine(punto1.getX(), punto1.getY(),punto2.getX(), punto2.getY());}
 
public double calcularDistancia(punto a, punto b){
    double distancia = 0;
        
    int xDif = b.getX() - a.getX();
    int yDif = b.getY() - a.getY();
                
    distancia = Math.sqrt( (xDif * xDif) + (yDif * yDif));
    return distancia;}
     
public void limpiarPanel (Graphics areaDibujo, JPanel PDibujo){
    int ancho = PDibujo.getWidth();
    int altura = PDibujo.getHeight();
    areaDibujo.setColor(Color.white);
    areaDibujo.fillRect(0, 0, ancho, altura);}

public void avanzarDerecha(Graphics areaDibujo, int distancia){
    areaDibujo.drawLine(x, y, x + distancia, y);}
     
public void avanzarArriba(Graphics areaDibujo, int distancia){
    areaDibujo.drawLine(x, y, x, y - distancia);}

public void avanzarAbajo(Graphics areaDibujo, int distancia){
    areaDibujo.drawLine(x, y, x, y + distancia);}

public void avanzarIzquierda(Graphics areaDibujo, int distancia){
    areaDibujo.drawLine(x, y, x- distancia, y);}

}