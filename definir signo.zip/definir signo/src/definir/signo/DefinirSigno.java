package definir.signo;
public class DefinirSigno {
    public static void main(String[] args) {
    interfaz z= new interfaz();
    z.setVisible(true);} }
