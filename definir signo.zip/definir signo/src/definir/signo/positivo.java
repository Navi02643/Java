/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package definir.signo;

/**
 *
 * @author Ivan
 */
public class positivo {
    
    public String definicion(double numero){
    String msg = "";
    if (numero==0){msg= "El numero " + numero + " es nulo\n";}
    else{
        if(numero>0){
        msg="El numero " + numero + " es +\n";}
        else{
        msg= "El numero " + numero + " es -\n";}}
    return msg;} 
    
    public String par(double numero){
    String respuesta="";
    if(numero==0){
    respuesta= "El numero "+numero+" no se puede clasificar\n";}
    else{
        if(numero%2==0){
        respuesta="El numero"+numero+"es par\n";}
        else{
        respuesta= "El numero "+numero+" Impar\n";}}
    return respuesta;}
    
    public String tipotri(double x,double y, double z){
    String triangulo="";
    if (x==0 || y==0 || z==0){
    triangulo="No es un triangulo\n";}
    else{
        if(x==y && y==z){
        triangulo="Es Equilatero\n";}
        else{
            if(x!=y && y!=z && z!=x){
            triangulo= "Es Escaleno\n";}
            else{
            triangulo="Es Isoseles\n";}}}
    return triangulo;}
    
    public String resolverecuacion(int a,int b,int c){
    double X1 = 0,X2 = 0;
    String solucion = "";
    double numero= (b*b)-(4*a*c);
    if(numero>=0){
        X1 = ((-1*b) + Math.sqrt(numero)) / 2*a;
        X2 = ((-1*b) - Math.sqrt(numero)) / 2*a;
        solucion="X1 = "+X1+"  "+" X2 = "+"  "+ X2+"\n";}
    else{
        solucion="No tiene solucion\n";}        
    return solucion;    
    }
    
    public String mayormenor(int N1, int N2, int N3){
    String msg="";
    if (N1==N2 && N2==N3){
    msg="Los numeros son iguales\n";}
    else{
        if(N1==N2 && N2>N3){
        msg="El Numero 1 y Numero 2 son mayores e iguales\n";}
        else{
            if(N1==N3 && N1>N2){
                msg="El Numero 1 y Numero 3 son mayores e iguales\n";}
            else{
                if(N1<N2 && N2==N3){
                    msg="El Numero 2 y Numero 3 son mayores e iguales\n";}
                else{
                   if(N3>N2 && N2>N1){
                       msg="El numero 3 es mayor\n";}
                   else{
                       if(N2>N1 && N3<N1){
                        msg="El numero 2 es mayor\n";}
                       else{
                       msg="El numero 1 es mayor\n";}}}}}}
    return msg;}
    
    public String Imprimircerohasta(int inicio ,int fin){
    String cadenaResultado="";
    if (inicio<0){
        cadenaResultado="Solo numeros positivos\n";}
    else{
        for(int i=inicio; i<=fin;i++){
            cadenaResultado=cadenaResultado+i+"\n";}}
    return cadenaResultado;}
    
    public String Imprimirpar(int inicio ,int fin){
    String cadenaResultado="";
    if (inicio%2==0){
        for(int i=inicio; i<=fin;i=i+2){
            cadenaResultado=cadenaResultado+i+"\n";}}
    else{
        inicio=inicio-1;
        for(int i=inicio; i<=fin;i=i+2){
            cadenaResultado=cadenaResultado+i+"\n";}}
    return cadenaResultado;}
    
    public String Imprimirimpar(int inicio ,int fin){
    String cadenaResultado="";
    if (inicio%2!=0){
        for(int i=inicio; i<=fin;i=i+2){
            cadenaResultado=cadenaResultado+i+"\n";}}
    else{
        inicio=inicio+1;
        for(int i=inicio;i<fin;i=i+2){
            cadenaResultado=cadenaResultado+i+"\n";}}
    return cadenaResultado;}
    
    public String ciclo(int ZX){
    String Mensaje = "";
    while(ZX>1){
        if(ZX%2!=0){
            ZX=ZX*3+1;
            Mensaje=Mensaje+ZX+"\n";}
        else{
            ZX=ZX/2;
            Mensaje=Mensaje+ZX+"\n";}
    }
    return Mensaje;}
}